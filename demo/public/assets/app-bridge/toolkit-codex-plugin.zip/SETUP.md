# Toolkit application bridge

This source-only Codex plugin packages the gateway, MCP connections and the app-to-mcp skill. It requires an existing configured Toolkit runtime. Set MODDING_LAB_ROOT privately before invoking it. Native mode uses that runtime's interpreter; no engines are installed or started automatically. For portable gateway testing, set MODDING_LAB_MODE=portable and install the repository's pinned MCP development dependency in your interpreter. The legacy plugin name is retained for compatibility.
